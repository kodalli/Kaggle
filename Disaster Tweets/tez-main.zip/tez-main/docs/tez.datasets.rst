Tez Datasets
=================

Some useful dataset classes used all the time.


.. automodule:: tez.datasets.generic
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: tez.datasets.image_classification
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: tez.datasets.image_segmentation
   :members:
   :undoc-members:
   :show-inheritance:
