Tez Model
=================

Tez Model is the core and the only important class in Tez. 

.. automodule:: tez.model.model
   :members:
   :undoc-members:
   :show-inheritance:
